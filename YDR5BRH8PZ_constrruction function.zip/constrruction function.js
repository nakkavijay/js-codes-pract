function car(color,brand){
    this.color = color;
    this.brand = brand;
    this.start = function(){
        console.log("started");
    }
}
let car1 = new car("blue", "dfsdaf");
console.log(car1)
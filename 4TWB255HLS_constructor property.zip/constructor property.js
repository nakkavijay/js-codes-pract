function car(color,brand){
    this.color = color;
    this.brand = brand;
    this.started = function(){
        console.log("started");
    };
}
let car1 = new car("blue","fsdl");
console.log(car1.constructor)
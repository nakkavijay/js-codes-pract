function createCar(color,brand) {
    return {
        color : color,
        brnad:brand,
        start: function() {
            console.log("started");
        }
    }
}
let car1= createCar("green", "dfd");
let car2= createCar("greendf", "sdafsa");
let car3= createCar("fddd", "fdasfa");

console.log(car1)
console.log(car2)
console.log(car3)
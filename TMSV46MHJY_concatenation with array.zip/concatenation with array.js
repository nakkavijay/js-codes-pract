let arr1 = [3,4];
let arr2 = [4,5];
let arr3 = [...arr1, ...arr2];
console.log(arr3); //array(4)[ 3,4,4,5 ]
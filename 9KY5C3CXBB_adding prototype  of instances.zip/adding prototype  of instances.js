// Accesing 
function Person(firstName, lastName){
    this.firstName = firstName;
    this.lastName = lastName;
}
Person.prototype.diplayFullName = function(){
    return this.firstName + " " + this.lastName;
}


let personal = new Person("dfkds", "dskfa");
let person2 = new Person("dfkfdsdss", "dsdfsfakfa");

//console.log(person2.diplayFullName());
//diplayFullName person1 and person 2 checking below objecy TypeError
console.log(Object.getPrototypeOf(personal) === Object.getPrototypeOf(person2));

//console.log(personal)
//console.log(person2)
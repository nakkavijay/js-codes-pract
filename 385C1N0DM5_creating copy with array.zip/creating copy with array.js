let arr1 =[1,3,3];
let arr2 =[...arr1];
console.log(arr2); //array(3)[ 1,3,3 ]
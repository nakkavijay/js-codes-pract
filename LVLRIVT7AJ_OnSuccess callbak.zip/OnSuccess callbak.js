const URL = "https://apis.ccbp.in/jokes/random";
const responseObject = fetch(URL);
responseObject
    .then((response) => {
        return response.json();
    })
    .then((data) => {
        console.log(data);
    })
    .catch((error) => {
        console.log(error);
    })
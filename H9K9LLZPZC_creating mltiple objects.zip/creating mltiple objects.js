function Person(firstName, lastName){
    this.firstName = firstName;
    this.lastName = lastName;
    
}
let personal = new Person("dfkds", "dskfa");
let person2 = new Person("dfksjf", "djfksajf");
console.log(personal);
console.log(person2);
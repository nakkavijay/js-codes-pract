let person={
    name: "dsfk",
    age:33,
    run: function(){
        console.log("start running");
        
    },
    habits: ["playain chess", "dfjksa"],
    car: {
        name: "audi",
        model: "er",
    }
};
console.log(person.car.name);

console.log(person.car["model"]);
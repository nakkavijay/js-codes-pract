let arr1 = [2,3,3];
let arr2 = [1,...arr1,4];
console.log(arr2)  //Array(5)[ 1,2,3,3,4 ]
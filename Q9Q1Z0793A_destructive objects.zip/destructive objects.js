let {firstname,...rest} = {firstname : "Rahul", age: 34, city: "Hyderabs"}
console.log(firstname);

console.log(rest);
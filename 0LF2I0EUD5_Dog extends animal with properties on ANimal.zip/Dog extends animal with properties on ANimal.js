class Animal {
    constructor(name){
        this.name = name;
    }
    eat(){
        return `${this.name} is eating`;
        
    }
    makeSound(){
        return `${this.name} is shouting`;
    }
}
// extends animal class lo una proprties ani dog ane propetirs ki inheritance cheyali

class Dog extends Animal{
    constructor(name,bread){
        super(name);
        this.bread = bread;
        
    }
    sniff(){
        return `${this.name} is sniffing`;
        
    }
}
let somedog = new Dog("sumdog","german shefferd");
console.log(somedog.sniff());
console.log(somedog.eat());
console.log(somedog.makeSound());
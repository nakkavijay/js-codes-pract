let person = {name: "rahul", age : 34}
let person_detials = {city:"Hyderabad", pincode :5000001};

let person_object = {...person,...person_detials}
console.log(person_object)
// switch statement

let day = 17;
switch (day){
    case 0:
        console.log("sunday");
        break;
        
    case 1:
        console.log("Monday");
        break;
        
    case 2:
        console.log("tuesday");
        break;
        
    case 3:
        console.log("wenesday");
        break;
    case 4:
        console.log("tuesday");
        break;
    case 5:
        console.log("friday");
        break;
    case 6:
        console.log("saturday");
        break;
        
    default:
        console.log("Invalid");
        break;
}
let age= 34;
//block scope betwen the curly brasses

if (age > 18){
    let x = 0;
    console.log(x);
}
// refference error x is not undefined
console.log(x);
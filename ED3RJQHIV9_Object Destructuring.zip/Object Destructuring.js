// objet Destrucuring
let person = {
    name:"ragul",
    age: 34
}
let {name} = person;
console.log(name);
console.log(person.name);
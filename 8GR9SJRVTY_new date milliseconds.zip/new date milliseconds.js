let time1 = new Date(0);
console.log(time1);

let time2 = new Date(100000000000);
console.log(time2)
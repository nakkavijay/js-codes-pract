//example -creating copy
let arr1 = [2,3];
let arr2 = [...arr1]
console.log(arr2)
class Animal {
    constructor(name){
        this.name = name;
    }
    eat(){
        return `${this.name} is eating`;
        
    }
    makeSound(){
        return `${this.name} is shouting`;
    }
}
// extends animal class lo una proprties ani dog ane propetirs ki inheritance cheyali

class Dog extends Animal{
    constructor(name,bread){
        super(name);
        this.bread = bread;
        
    }
    sniff(){
        return `${this.name} is sniffing`;
        
    }
}

class Cat extends Animal{
    constructor(name, bread){
        super(name);
        this.bread = bread;
    }
    kneed(){
        return `${this.name} is kneading`;
        
    }
}
let personCat = new Cat("someCat", "parsientCat");
console.log(personCat.eat())
console.log(personCat.makeSound())
console.log(personCat.kneed())
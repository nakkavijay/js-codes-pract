//creating an instance
function Car(color,brand){
    this.color= color;
    this.brand= brand;
    this.start= function(){
        console.log("started");                                
    };
}
let car1 = new Car("dfa","dfask");

console.log(Object.getPrototypeOf(car1));
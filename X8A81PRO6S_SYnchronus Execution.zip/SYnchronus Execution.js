alert("First Line");
alert("Second line");
alert("Third Line");
alert("forth Line");
alert("fifth Line");
alert("six Line");
alert("Seventh Line");
alert("Eight Line");
alert("Nine Line");
alert("Tenth Line");
alert("leventh Line ");
alert("Twelth Line")
alert("Thirtenth Line");
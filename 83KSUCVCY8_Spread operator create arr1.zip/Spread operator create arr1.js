//spread operators
//my Array

let arr1 = [2,4];
let arr2 = [1, ...arr1 , 3, 5];
console.log(arr2)
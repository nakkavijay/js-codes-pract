class Person{
    constructor(firstName, lastName){
        this.firstName = firstName;
        this.lastName = lastName;
        
    }
    displayFullName(){
        return this.firstName +" "+ this.lastName;
    }
}
let viratObj = new Person("Virat", "Kohli");
console.log(viratObj);
console.log(viratObj.displayFullName())
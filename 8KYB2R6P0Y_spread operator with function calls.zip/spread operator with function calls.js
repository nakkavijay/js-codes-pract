function add(a,b,c) {
    return a+b+c;
}
let numbers = [1,3,4,5];
console.log(add(...numbers))
const URL = "https://apis.ccbp.i/jokes/random";
const doNetworkCall = async () =>{
    try {
        const response = await fetch(URL);
        const jsonData = await response.json();
        console.log(jsonData);
    }catch(err){
        console.log(err);
    }
    
};
doNetworkCall();
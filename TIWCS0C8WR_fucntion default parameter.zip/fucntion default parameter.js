function sum(a, b= 3,c=4){
    return b+c;
    
}
console.log(sum(1,5));
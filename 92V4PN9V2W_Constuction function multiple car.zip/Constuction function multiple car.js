//Constructor function 
function Car(color, brand){
    this.color = color;
    this.brand = brand;
    this.stat = function(){
        console.log("started");
    };
}
let car1 = new Car("blue", "df");
let car2 = new Car("bldffue", "dfddf");
let car3 = new Car("blfdfue", "dadff");

console.log(car1)
console.log(car2)
console.log(car3)
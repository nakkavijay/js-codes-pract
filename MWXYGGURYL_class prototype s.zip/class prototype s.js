class Person{
    constructor(firstName, lastName){
        this.firstName = firstName;
        this.lastName = lastName;
        
    }
    displayFullName(){
        return this.firstName +" "+ this.lastName;
    }
}
// same output vastundi\
console.log(Person.prototype);
let viratObj = new Person("Virat", "Kohli");
console.log(Object.getPrototypeOf(viratObj));
//console.log(viratObj);
//console.log(viratObj.displayFullName())
let myArray = new Array("a", 2, true);
//myrray constructor function is Array
console.log(Object.getPrototypeOf(myArray));
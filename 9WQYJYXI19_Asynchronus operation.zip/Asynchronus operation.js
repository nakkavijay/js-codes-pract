const URL = "https://apis.ccbp.in/jokes/random";
fetch(URL).then((response) => {
        return response.json();
    })
    .then((jsonData) => {
        console.log(jsonData);

    });
console.log("fetching done");
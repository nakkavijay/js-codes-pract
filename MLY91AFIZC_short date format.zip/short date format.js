let date = new Date("03/25/2015");
console.log(date);
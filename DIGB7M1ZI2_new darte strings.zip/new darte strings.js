let date = new Date("2020-08");
console.log(date);
let date1 = new Date("2020");
console.log(date1)
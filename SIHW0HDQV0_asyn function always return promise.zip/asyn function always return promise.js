const URL = "https://apis.ccbp.in/jokes/random";
const doNetworkCall = async () =>{
    try {
        const response = await fetch(URL);
        const jsonData = await responseit.json();
        console.log(jsonData);
    }catch(err){
        console.log(err);
    }
    
};
const asyncPromise = doNetworkCall();
console.log(asyncPromise);
function Person(firstName){
    this.firstName = firstName;
   
}
Person.prototype.diplayFullName = function(){
    return this.firstName ;
}


let personal = new Person("dfkds");


//console.log(person2.diplayFullName());
//diplayFullName person1 and person 2 checking below objecy TypeError
console.log(Object.getPrototypeOf(personal));
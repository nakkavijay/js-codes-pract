function car(color, brand){
    this.color = color;
    this.brand = brand;
    this.start = function() {
        console.log("started");
        
    }
}
console.log(car.name);
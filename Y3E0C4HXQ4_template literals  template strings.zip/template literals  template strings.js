//the template literals are enclosd by the backticks
// they ar used to 1,embed variables or expression in the strings
// 2. write multiple strings
let firstname = "rahul";
console.log(`hello ${firstname}!`); // hello rahul!
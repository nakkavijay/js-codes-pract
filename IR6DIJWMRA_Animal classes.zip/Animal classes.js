//create Animal class

class Animal {
    constructor(name){
        this.name = name;
    }
    eat(){
        return `${this.name} is eating`;
        
    }
    makeSound(){
        return `${this.name} is shouting`;
    }
}
let gorillaobj = new Animal("gorilla");
console.log(gorillaobj);
console.log(gorillaobj.eat())
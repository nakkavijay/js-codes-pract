function numbers(a=2,b=4){
    console.log(a);
    console.log(b);
    
}
numbers(3,35);
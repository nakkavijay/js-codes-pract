const URL = "https://apis.ccbp.in/jokes/random";
let responseObject = fetch(URL);
console.log(responseObject);
console.log("fetching done");
function numbers(...args){
    console.log(args);
}
numbers(2,4,56,6);